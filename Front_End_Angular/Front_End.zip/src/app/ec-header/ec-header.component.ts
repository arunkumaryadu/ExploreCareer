import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ec-header',
  templateUrl: './ec-header.component.html',
  styleUrls: ['./ec-header.component.css']
})
export class EcHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
