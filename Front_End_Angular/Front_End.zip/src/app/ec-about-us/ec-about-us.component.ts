import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ec-about-us',
  templateUrl: './ec-about-us.component.html',
  styleUrls: ['./ec-about-us.component.css']
})
export class EcAboutUsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
