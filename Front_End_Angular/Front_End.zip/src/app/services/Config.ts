export class EcConfig{

    constructor() { }
  
    static BaseIp='http://192.168.43.54:7080/exploreyourcareer/';
    
   
}  