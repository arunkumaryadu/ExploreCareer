export class Subject{
  name:string;
  details:string;
}
